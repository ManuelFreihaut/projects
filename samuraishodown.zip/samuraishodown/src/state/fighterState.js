export const createDefaultFighterState = (id) => ({
    id,
    score: 1,
    battles: 0,
});