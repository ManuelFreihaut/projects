
import { createDefaultFighterState } from './fighterState.js';
import { FighterId } from '../constants/fighter.js';

export const gameState = {  //^ ---> you can select between (Haohmaru && Charlotte || Shizumaru && Hattori)
    fighters: [
        createDefaultFighterState(FighterId.HAOHMARU),
        createDefaultFighterState(FighterId.CHARLOTTE),
        // createDefaultFighterState(FighterId.SHIZUMARU),
        // createDefaultFighterState(FighterId.HATTORI),
    ]
}