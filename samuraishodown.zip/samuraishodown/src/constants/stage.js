//^ ---> enable values for your selected Stage, disable for the last one

// export const STAGE_FLOOR = 267; //267 //* Temple / Dojo
// export const STAGE_FLOOR = 287; //* Buddha
export const STAGE_FLOOR = 280; //* Bridge

// ^ Dojo Stage
// export const STAGE_WIDTH = 624;
// export const STAGE_HEIGHT = 444;
// ^
// ^ Temple Stage
// export const STAGE_WIDTH = 640; //!  Width of floor
// export const STAGE_HEIGHT = 351;//!  Height of background
// ^
 // ^ Buddha Stage
// export const STAGE_WIDTH = 640;
// export const STAGE_HEIGHT = 477;
// ^
// ^ Bridge Stage
export const STAGE_WIDTH = 624;
export const STAGE_HEIGHT = 336;
// ^

export const STAGE_MID_POINT = STAGE_WIDTH / 2;
export const STAGE_PADDING = 256;

export const SCROLL_BOUNDRY = 200;