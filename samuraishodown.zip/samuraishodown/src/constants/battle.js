export const TIME_DELAY = 664;
export const TIME_FLASH_DELAY = 50;
export const TIME_FRAME_KEYS = ['time', 'time-flash'];
