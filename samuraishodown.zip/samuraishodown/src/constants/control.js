export const Control = {
    LEFT: 'left',
    RIGHT: 'right',
    UP: 'up',
    DOWN: 'down',
    LIGHT_SLASH: 'lightSlash',
    MEDIUM_SLASH: 'mediumSlash',
    HARD_SLASH: 'hardSlash',
    KICK: 'kick',
};

export const controls = [
    {
        keyboard: {
            [Control.LEFT]: 'KeyD',
            [Control.RIGHT]: 'KeyG',
            [Control.UP]: 'KeyR',
            [Control.DOWN]: 'KeyF',
            [Control.LIGHT_SLASH]: 'KeyZ',
            [Control.HARD_SLASH]: 'KeyA',
        },
    },
    {
        keyboard: {
            [Control.LEFT]: 'KeyJ',
            [Control.RIGHT]: 'KeyL',
            [Control.UP]: 'KeyI',
            [Control.DOWN]: 'KeyK',
            [Control.LIGHT_SLASH]: 'Slash',
            [Control.HARD_SLASH]: 'Quote',
        },
    },
]