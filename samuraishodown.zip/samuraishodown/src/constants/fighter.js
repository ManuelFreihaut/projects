export const FIGHTER_START_DISTANCE = 88;

export const FighterDirection = {
    LEFT: -1,
    RIGHT: 1,
};

export const FighterId = { //^ ---> you can select between (Haohmaru && Charlotte || Shizumaru && Hattori)
    HAOHMARU: 'Haohmaru',
    CHARLOTTE: 'Charlotte',
    // SHIZUMARU: 'Shizumaru',
    // HATTORI: 'Hattori',
}

export const FighterAttackType = {
    SLASH: 'slash',
    KICK: 'kick',
}

export const FighterState = {
    IDLE: 'idle',
    WALK_FORWARD: 'walkForwards',
    WALK_BACKWARD: 'walkBackwards',
    JUMP_START: 'jumpStart',
    JUMP_UP: 'jumpUp',
    JUMP_LAND: 'jumpLand',
    CROUCH: 'crouch',
    CROUCH_DOWN: 'crouchDown',
    CROUCH_UP: 'crouchUp',
    IDLE_TURN: 'idleTurn',
    CROUCH_TURN: 'crouchTurn',
    LIGHT_SLASH: 'lightSlash',
    MEDIUM_SLASH: 'mediumSlash',
    HARD_SLASH: 'hardSlash',
    KICK: 'kick',
};

/*export const FrameDelay = {
    FREEZE: 0,
    TRANSITION: -2,
};*/

export const PushBox = {
    IDLE: [-16, -80, 32, 78],
    JUMP: [-16, -91, 32, 66],
    BEND: [-16, -58, 32, 58],
    CROUCH: [-16, -70, 32, 70],
}

export const HurtBox = {
    IDLE: [[-8, -88, 24, 16], [-26, -74, 40, 42], [-26, -31, 40, 32]],
    FORWARD: [[-8, -88, 24, 16], [-26, -74, 40, 42], [-26, -31, 40, 32]],
    BACKWARD: [[-8, -88, 24, 16], [-26, -74, 40, 42], [-26, -31, 40, 32]],
    JUMP: [[-8, -88, 24, 16], [-26, -74, 40, 42], [-26, -31, 40, 32]],
    BEND: [[-8, -88, 24, 16], [-26, -74, 40, 42], [-26, -31, 40, 32]],
    CROUCH: [[-8, -68, 24, 16], [-26, -54, 40, 32], [-26, -21, 40, 22]],
    SLASH: [[5, -88, 24, 16], [-11, -74, 40, 42], [-11, -31, 40, 32]],

}
 