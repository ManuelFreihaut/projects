import { TIME_DELAY, TIME_FLASH_DELAY, TIME_FRAME_KEYS } from '../../constants/battle.js';
import { gameState } from '../../state/gameState.js';

export class StatusBar {
    constructor() {
        this.image = document.querySelector('img[alt="misc"]');
        this.tags = document.querySelector('img[alt="tags"]'); //A

        this.time = 99;
        this.timeTimer = 0;
        this.timeFlashTimer = 0;
        this.useFlashFrames = false;

        this.frames = new Map([
            // Misc Image
            ['health-bar', [16, 18, 145, 11]],

            ['ko-white', [161, 16, 32, 14]],

            [`${TIME_FRAME_KEYS[0]}-0`, [16, 32, 14, 16]],
            [`${TIME_FRAME_KEYS[0]}-1`, [32, 32, 14, 16]],
            [`${TIME_FRAME_KEYS[0]}-2`, [48, 32, 14, 16]],
            [`${TIME_FRAME_KEYS[0]}-3`, [64, 32, 14, 16]],
            [`${TIME_FRAME_KEYS[0]}-4`, [80, 32, 14, 16]],
            [`${TIME_FRAME_KEYS[0]}-5`, [96, 32, 14, 16]],
            [`${TIME_FRAME_KEYS[0]}-6`, [112, 32, 14, 16]],
            [`${TIME_FRAME_KEYS[0]}-7`, [128, 32, 14, 16]],
            [`${TIME_FRAME_KEYS[0]}-8`, [144, 32, 14, 16]],
            [`${TIME_FRAME_KEYS[0]}-9`, [160, 32, 14, 16]],

            [`${TIME_FRAME_KEYS[1]}-0`, [16, 192, 14, 16]],
            [`${TIME_FRAME_KEYS[1]}-1`, [32, 192, 14, 16]],
            [`${TIME_FRAME_KEYS[1]}-2`, [48, 192, 14, 16]],
            [`${TIME_FRAME_KEYS[1]}-3`, [64, 192, 14, 16]],
            [`${TIME_FRAME_KEYS[1]}-4`, [80, 192, 14, 16]],
            [`${TIME_FRAME_KEYS[1]}-5`, [96, 192, 14, 16]],
            [`${TIME_FRAME_KEYS[1]}-6`, [112, 192, 14, 16]],
            [`${TIME_FRAME_KEYS[1]}-7`, [128, 192, 14, 16]],
            [`${TIME_FRAME_KEYS[1]}-8`, [144, 192, 14, 16]],
            [`${TIME_FRAME_KEYS[1]}-9`, [160, 192, 14, 16]],


            ['char-A', [29, 113, 11, 10]],
            ['char-B', [41, 113, 10, 10]],
            ['char-C', [53, 113, 10, 10]],
            ['char-D', [65, 113, 10, 10]],
            ['char-E', [77, 113, 10, 10]],
            ['char-F', [89, 113, 10, 10]],
            ['char-G', [101, 113, 10, 10]],
            ['char-H', [113, 113, 10, 10]],
            ['char-I', [127, 113, 5, 10]],
            ['char-J', [137, 113, 8, 10]],
            ['char-K', [149, 113, 10, 10]],
            ['char-L', [161, 113, 10, 10]],
            ['char-M', [173, 113, 11, 10]],
            ['char-N', [185, 113, 11, 10]],
            ['char-O', [197, 113, 10, 10]],
            ['char-P', [17, 125, 10, 10]],
            ['char-Q', [29, 125, 10, 10]],
            ['char-R', [41, 125, 11, 10]],
            ['char-S', [53, 125, 10, 10]],
            ['char-T', [65, 125, 10, 10]],
            ['char-U', [77, 125, 10, 10]],
            ['char-V', [89, 125, 10, 10]],
            ['char-W', [101, 125, 11, 10]],
            ['char-X', [113, 125, 10, 10]],
            ['char-Y', [125, 125, 11, 10]],
            ['char-Z', [137, 125, 10, 10]],

            // Name Tags //A
            ['tag-haohmaru', [0, 0, 52, 6]],
            ['tag-charlotte', [0, 7, 56, 6]],
            ['tag-shizumaru', [0, 14, 55, 6]],
            ['tag-hattori', [0, 21, 32, 6]],
        ]);

        this.names = gameState.fighters.map(({ id }) => `tag-${id.toLowerCase()}`);

    }

    updateTime(time) {
        if(time.previous > this.timeTimer + TIME_DELAY) {
            this.time -= 1;
            this.timeTimer = time.previous;
        }

        if(this.time < 15 && this.time > -1
            && time.previous > this.timeFlashTimer + TIME_FLASH_DELAY
        ) {
            this.useFlashFrames = !this.useFlashFrames;
            this.timeFlashTimer = time.previous;
        }
    }

    update(time) {
        this.updateTime(time)
    }

    /*drawFrame(context, image, frameKey, x, y, direction = 1) {
        drawFrame(context, image, this.frames.get(frameKey), x, y, direction);
    }*/

    drawFrame(context, image/*A*/, frameKey, x, y, direction = 1) {
        const [sourceX, sourceY, sourceWidth, sourceHeight] = this.frames.get(frameKey);
    
        context.scale(direction *0.92, 1);
        context.drawImage(
            image,//this.image,
            sourceX, sourceY, sourceWidth, sourceHeight,
            x * direction, y, sourceWidth, sourceHeight,
        );
        context.setTransform(1, 0, 0, 1, 0, 0);
    }

    drawHealtBars(context) {
        this.drawFrame(context, this.image, 'health-bar', 31, 18);
        this.drawFrame(context, this.image, 'ko-white', 176, 16);
        this.drawFrame(context,this.image, 'health-bar', 353, 18, -1);
    }

    drawNameTags(context) {
        const [name1, name2] = this.names;

        this.drawFrame(context, this.tags, name1, 32, 35);
        this.drawFrame(context, this.tags, name2, 302, 35);
    }

    drawTime(context) {
        const timeString = String(Math.max(this.time, 0)).padStart(2, '00');
        const flashFrame = TIME_FRAME_KEYS[Number(this.useFlashFrames)];

        this.drawFrame(context, this.image, `${flashFrame}-${timeString.charAt(0)}`, 178, 31);
        this.drawFrame(context, this.image, `${flashFrame}-${timeString.charAt(1)}`, 194, 31);
    }

    draw(context) {
        this.drawHealtBars(context);
        this.drawNameTags(context);
        this.drawTime(context);

    }
}