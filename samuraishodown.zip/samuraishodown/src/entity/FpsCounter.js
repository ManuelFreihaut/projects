export class FpsCounter {
    console() {
        this.fps = 0;
    }
    
    update(frameTime) { //time
        this.fps = Math.trunc(1 / frameTime.secondsPassed);
    }

    draw(context) {
        context.FpsCounter = '14px Arial';
        context.fillStyle = '#00FF00';
        context.textAlign = 'right';
        context.fillText(`${this.fps}`, context.canvas.width - 2, context.canvas.height - 2);
    }
}