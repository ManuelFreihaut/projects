export class Stage {
    constructor(stage/*A*/) {
        this.image = document.querySelector('img[alt="stage"]');

        this.stage = stage; //'dojo /*A*/

        this.frames = new Map([/*stage-background*/
            [`dojo-background`, [, , , ]],
            [`dojo-floor`, [21, 633, 624, 444]],

            [`buddha-background`, [7, 0, 640, 477]],
            ['buddha-floor', [10, 488, 640, 356]],

            [`bridge-background`, [100, 66, 696, 224]],
            ['bridge-floor', [23, 874, 624, 309]],

            [`temple-background`, [6, 5, 639, 351]],
            ['temple-floor', [6, 385, 640, 283]],
        ])
    }

    update() {

    }

    drawFrame(context, frameKey, x, y) {
        const [sourceX, sourceY, sourceWidth, sourceHeight] = this.frames.get(frameKey);

        context.drawImage(
            this.image,// image.
            sourceX, sourceY, sourceWidth, sourceHeight,
            x, y, sourceWidth, sourceHeight,
        );
    }

    draw(context, camera) {

        switch(this.stage) {
            case 'dojo': // * Dojo Stage
                this.drawFrame(context, `${this.stage}-floor`, Math.floor(256 - camera.position.x), -145 - camera.position.y);
                // this.drawFrame(context, `${this.stage}-floor`, 0, 0);
            break;
            case 'temple': // * Temple Stage
                this.drawFrame(context, `${this.stage}-background`, Math.floor(119 - (camera.position.x / 2)), -130 - camera.position.y);
                this.drawFrame(context, `${this.stage}-floor`, Math.floor(256 - camera.position.x), +14 - camera.position.y);
            break;
            case 'buddha': // * Buddha Stage
                this.drawFrame(context, `${this.stage}-background`, Math.floor(119 - (camera.position.x / 2)), -165 - camera.position.y);
                this.drawFrame(context, `${this.stage}-floor`, Math.floor(256 - camera.position.x), -57 - camera.position.y);
            break;
            case 'bridge': // * Bridge Stage
                this.drawFrame(context, `${this.stage}-background`, Math.floor(119 - (camera.position.x / 1.15784)), -65 - camera.position.y);
                this.drawFrame(context, `${this.stage}-floor`, Math.floor(256 - camera.position.x), -10 - camera.position.y);
            break;
        }
         //-192, -156
        // this.drawFrame(context, `${this.stage}-floor`, -256, -6);
         //257, -145
    }

    
}

//funciton updateBackground() {}
