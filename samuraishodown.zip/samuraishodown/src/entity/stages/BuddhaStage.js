export class BuddhaStage {
    constructor() {
        this.image = document.querySelector('img[alt="buddhaStage"]');

        this.frames = new Map([/*stage-background*/
            [`buddha-background`, [7, 0, 640, 477]],
            ['buddha-floor', [10, 488, 640, 356]],
        ])
    }

    update() {

    }

    drawFrame(context, frameKey, x, y) {
        const [sourceX, sourceY, sourceWidth, sourceHeight] = this.frames.get(frameKey);

        context.drawImage(
            this.image,
            sourceX, sourceY, sourceWidth, sourceHeight,
            x, y, sourceWidth, sourceHeight,
        );
    }

    draw(context, camera) {
        this.drawFrame(context, `buddha-background`, Math.floor(119 - (camera.position.x / 2)), -165 - camera.position.y);
        this.drawFrame(context, `buddha-floor`, Math.floor(256 - camera.position.x), -57 - camera.position.y);
    }
}