export class DojoStage {
    constructor() {
        this.image = document.querySelector('img[alt="dojoStage"]');

        this.frames = new Map([/*stage-background*/
            [`dojo-background`, [, , , ]],
            [`dojo-floor`, [21, 633, 624, 444]],
        ]);
    }

    update(frame) {

    }

    drawFrame(context, frameKey, x, y) {
        const [sourceX, sourceY, sourceWidth, sourceHeight] = this.frames.get(frameKey);

        context.drawImage(
            this.image,
            sourceX, sourceY, sourceWidth, sourceHeight,
            x, y, sourceWidth, sourceHeight,
        );
    }

    draw(context, camera) {

     this.drawFrame(context, `dojo-floor`, Math.floor(256 - camera.position.x), -145 - camera.position.y);

    }
}