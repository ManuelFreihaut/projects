export class TempleStage {
    constructor() {
        this.image = document.querySelector('img[alt="templeStage"]');

        this.frames = new Map([/*stage-background*/
            [`temple-background`, [6, 5, 639, 351]],
            ['temple-floor', [6, 385, 640, 283]],
        ])
    }

    update() {

    }

    drawFrame(context, frameKey, x, y) {
        const [sourceX, sourceY, sourceWidth, sourceHeight] = this.frames.get(frameKey);

        context.drawImage(
            this.image,
            sourceX, sourceY, sourceWidth, sourceHeight,
            x, y, sourceWidth, sourceHeight,
        );
    }

    draw(context, camera) {
        this.drawFrame(context, `temple-background`, Math.floor(119 - (camera.position.x / 2)), -130 - camera.position.y);
        this.drawFrame(context, `temple-floor`, Math.floor(256 - camera.position.x), +16 - camera.position.y);
    }
}