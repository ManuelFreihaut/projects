export class BridgeStage {
    constructor() {
        this.image = document.querySelector('img[alt="bridgeStage"]');

        this.frames = new Map([/*stage-background*/
            [`bridge-background`, [100, 66, 696, 224]],
            ['bridge-floor', [23, 874, 624, 309]],
        ])
    }

    update(time) {

    }

    drawFrame(context, frameKey, x, y) {
        const [sourceX, sourceY, sourceWidth, sourceHeight] = this.frames.get(frameKey);

        context.drawImage(
            this.image,
            sourceX, sourceY, sourceWidth, sourceHeight,
            x, y, sourceWidth, sourceHeight,
        );
    }

    draw(context, camera) {
        this.drawFrame(context, `bridge-background`, Math.floor(119 - (camera.position.x / 1.15784)), -65 - camera.position.y);
        this.drawFrame(context, `bridge-floor`, Math.floor(256 - camera.position.x), -10 - camera.position.y);
    }
}