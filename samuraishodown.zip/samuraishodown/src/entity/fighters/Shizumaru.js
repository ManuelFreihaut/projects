import { FighterState, PushBox, HurtBox } from '../../constants/fighter.js';
import { Fighter } from './Fighter.js';

export class Shizumaru extends Fighter {
    
    constructor(playerId) {
        super('Shizumaru', playerId);

        this.image = document.querySelector('img[alt="shizumaru"]');

        let i = 98;
        let f = 71;
        let b = 92;

        let c = 113;
    
        this.frames = new Map([
            // Idle Stance
            ['idle-0', [[[0, 0, i, 150], [56, 146]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-1', [[[i, 0, i, 150], [56, 146]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-2', [[[i * 2, 0, i, 150], [56, 146]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-3', [[[i * 3, 0, i, 150], [56, 146]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-4', [[[i * 4, 0, i, 150], [56, 146]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-5', [[[i * 5, 0, i, 150], [56, 146]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-6', [[[i * 6, 0, i, 150], [56, 146]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-7', [[[i * 7, 0, i, 150], [56, 146]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-8', [[[i * 8, 0, i, 150], [56, 146]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-9', [[[i * 9, 0, i, 150], [56, 146]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-10', [[[i * 10, 0, i, 150], [56, 146]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-11', [[[i * 11, 0, i, 150], [56, 146]], PushBox.IDLE, HurtBox.IDLE]],

            // Move Forwards
            ['forwards-0', [[[0, 0, f, 150], [f / 2 + 7, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-1', [[[f, 0, f, 150], [f / 2 + 7, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-2', [[[f * 2, 0, f, 150], [f / 2 + 7, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-3', [[[f * 3, 0, f, 150], [f / 2 + 7, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-4', [[[f * 4, 0, f, 150], [f / 2 + 7, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-5', [[[f * 5, 0, f, 150], [f / 2 + 7, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-6', [[[f * 6, 0, f, 150], [f / 2 + 7, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-7', [[[f * 7, 0, f, 150], [f / 2 + 7, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-8', [[[f * 8, 0, f, 150], [f / 2 + 7, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-9', [[[f * 9, 0, f, 150], [f / 2 + 7, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-10', [[[f * 10, 0, f, 150], [f / 2 + 7, 150]], PushBox.IDLE, HurtBox.FORWARD]],

            // Move Backwards
            ['backwards-0', [[[0, 0, b, 150], [b / 2 + 9, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-1', [[[b, 0, b, 150], [b / 2 + 9, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-2', [[[b * 2, 0, b, 150], [b / 2 + 9, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-3', [[[b * 3, 0, b, 150], [b / 2 + 9, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-4', [[[b * 4, 0, b, 150], [b / 2 + 9, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-5', [[[b * 5, 0, b, 150], [b / 2 + 9, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-6', [[[b * 6, 0, b, 150], [b / 2 + 9, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-7', [[[0, 150, b, 150], [b / 2 + 9, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-8', [[[b, 150, b, 150], [b / 2 + 9, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-9', [[[b * 2, 150, b, 150], [b / 2 + 9, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-10', [[[b * 3, 150, b, 150], [b / 2 + 9, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-11', [[[b * 4, 150, b, 150], [b / 2 + 9, 150]], PushBox.IDLE, HurtBox.BACKWARD]],

            // Jump Up
            ['jump-up-0', [[[3, 70, 92, 80], [58, 100]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-1', [[[100, 79, 91, 71], [58, 100]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-2', [[[202, 87, 88, 63], [58, 100]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-3', [[[302, 84, 98, 66], [58, 100]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-4', [[[401, 83, 99, 67], [58, 100]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-5', [[[500, 74, 100, 75], [58, 100]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-6', [[[603, 63, 95, 87], [58, 100]], PushBox.JUMP, HurtBox.JUMP]],

            // Crouch
            ['crouch-0', [[[0, 0, c, 150], [79, 150]], PushBox.IDLE, HurtBox.CROUCH]],
            ['crouch-1', [[[c, 0, c, 150], [79, 150]], PushBox.BEND, HurtBox.CROUCH]],
            ['crouch-2', [[[c * 2, 0, c, 150], [79, 150]], PushBox.CROUCH, HurtBox.CROUCH]],

            // Stand Turn
            ['idle-turn-0', [[[0, 56, 79, 85], [50, 86]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-turn-1', [[[101, 53, 44, 88], [20, 91]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-turn-2', [[[170, 53, 47, 88], [25, 91]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-turn-3', [[[236, 57, 79, 84], [30, 86]], PushBox.IDLE, HurtBox.IDLE]],

            // Crouch Turn
            ['crouch-turn-0', [[[352, 78, 102, 71], [75, 70]], PushBox.CROUCH, HurtBox.CROUCH]],
            ['crouch-turn-1', [[[472, 75, 88, 73], [65, 70]], PushBox.CROUCH, HurtBox.CROUCH]],
            ['crouch-turn-2', [[[585, 77, 43, 73], [23, 70]], PushBox.CROUCH, HurtBox.CROUCH]],
            ['crouch-turn-3', [[[658, 81, 81, 69], [25, 65]], PushBox.CROUCH, HurtBox.CROUCH]],

            // Light Slashes
            ['light-slash-0', [[[47, 75, 65, 81], [27, 81]], PushBox.IDLE, HurtBox.SLASH]],
            ['light-slash-1', [[[130, 79, 146, 76], [27, 76]], PushBox.IDLE, HurtBox.SLASH]],
            ['light-slash-2', [[[297, 80, 149, 75], [27, 75]], PushBox.IDLE, HurtBox.SLASH, [71, -63, 50, 18]]],
            ['light-slash-3', [[[462, 79, 146, 76], [27, 76]], PushBox.IDLE, HurtBox.SLASH, [70, -63, 50, 18]]],
            ['light-slash-4', [[[628, 74, 65, 81], [27, 81]], PushBox.IDLE, HurtBox.SLASH, [68, -63, 50, 18]]],

            // Hard Slashes
            ['hard-slash-0', [[[28, 1222, 59, 83], [34, 83]], PushBox.IDLE, [[], [-11, -74, 40, 42], [-11, -31, 40, 32]]]],
            ['hard-slash-1', [[[108, 1225, 64, 80], [34, 80]], PushBox.IDLE, [[], [-11, -74, 40, 42], [-11, -31, 40, 32]]]],
            ['hard-slash-2', [[[184, 1233, 61, 72], [34, 72]], PushBox.IDLE, [[], [-11, -74, 40, 42], [-11, -31, 40, 32]]]],
            ['hard-slash-3', [[[257, 1231, 63, 74], [34, 74]], PushBox.IDLE]],
            ['hard-slash-4', [[[330, 1217, 89, 88], [34, 88]], PushBox.IDLE]],
            ['hard-slash-5', [[[440, 1189, 79, 116], [10, 116]], PushBox.IDLE]],
            ['hard-slash-6', [[[543, 1184, 101, 121], [4, 121]], PushBox.IDLE]],
            ['hard-slash-7', [[[668, 1233, 132, 72], [0, 72]], PushBox.IDLE]],
            ['hard-slash-8', [[[828, 1183, 137, 122], [0, 122]], PushBox.IDLE, ]],
            ['hard-slash-9', [[[28, 1342, 98, 60], [0, 60]], PushBox.IDLE, , [91, -63, 50, 18]]],
            ['hard-slash-10', [[[146, 1323, 144, 79], [0, 79]], PushBox.IDLE, [[67, -54, 24, 16], [51, -40, 40, 42], []], [101, -63, 50, 18]]],
            ['hard-slash-11', [[[303, 1345, 97, 57], [0, 57]], PushBox.IDLE, [[67, -54, 24, 16], [51, -40, 40, 42], []], [91, -43, 50, 18]]],
            ['hard-slash-12', [[[416, 1345, 119, 57], [0, 57]], PushBox.IDLE, [[67, -54, 24, 16], [51, -40, 40, 42], []], [71, -23, 50, 18]]],
            ['hard-slash-13', [[[554, 1337, 108, 65], [14, 65]], PushBox.IDLE, ]],
            ['hard-slash-14', [[[683, 1322, 79, 80], [34, 80]], PushBox.IDLE, ]],

        ]);

        this.animations = {
            [FighterState.IDLE]: [
                ['idle-0', 60], ['idle-1', 60], ['idle-2', 60], 
                ['idle-3', 60], ['idle-4', 60], ['idle-5', 60], 
                ['idle-6', 60], ['idle-7', 60], ['idle-8', 60],
                ['idle-9', 60], ['idle-10', 60], ['idle-11', 60],
            ],
            [FighterState.WALK_FORWARD]: [
                ['forwards-0', 60], ['forwards-1', 60], ['forwards-2', 60], 
                ['forwards-3', 60], ['forwards-4', 60], ['forwards-5', 60], 
                ['forwards-6', 60], ['forwards-7', 60], ['forwards-8', 60],
                ['forwards-9', 60], ['forwards-10', 60],
            ],
            [FighterState.WALK_BACKWARD]: [
                ['backwards-0', 80], ['backwards-1', 80], ['backwards-2', 80], 
                ['backwards-3', 80], ['backwards-4', 80], ['backwards-5', 80], 
                ['backwards-6', 80], ['backwards-7', 80], ['backwards-8', 80],
                ['backwards-9', 80], ['backwards-10', 80], ['backwards-11', 80]
            ],
            [FighterState.JUMP_UP]: [
                ['jump-up-0', 100], ['jump-up-1', 100], ['jump-up-2', 80],
                ['jump-up-3', 100], ['jump-up-4', 100], ['jump-up-5', 100],
                ['jump-up-6', 80]
            ],
            [FighterState.CROUCH]: [
                ['crouch-2', 0]
            ],
            [FighterState.CROUCH_DOWN]: [
                ['crouch-0', 50], ['crouch-1', 50], ['crouch-2', 50], ['crouch-1', -2],
            ],
            [FighterState.CROUCH_UP]: [
                ['crouch-2', 50], ['crouch-1', 50], ['crouch-0', 50], ['crouch-1', -2],
            ],
            [FighterState.IDLE_TURN]: [
                ['idle-turn-3', 65], ['idle-turn-2', 65], ['idle-turn-1', 65], ['idle-turn-0', 65], ['idle-turn-0', -2],
            ],
            [FighterState.CROUCH_TURN]: [
                ['crouch-turn-3', 65], ['crouch-turn-2', 65], ['crouch-turn-1', 65], ['crouch-turn-0', 65], ['crouch-turn-0', -2],
            ],
            [FighterState.LIGHT_SLASH]: [
                ['light-slash-0', 50], ['light-slash-1', 50], ['light-slash-2', 50], 
                ['light-slash-3', 70], ['light-slash-4', 70], ['light-slash-4', -2], 
            ],        
            [FighterState.HARD_SLASH]: [
                ['hard-slash-0', 60], ['hard-slash-1', 60], ['hard-slash-2', 60], 
                ['hard-slash-3', 60], ['hard-slash-4', 60], ['hard-slash-5', 60], 
                ['hard-slash-6', 40], ['hard-slash-7', 40], ['hard-slash-8', 80], 
                ['hard-slash-9', 80], ['hard-slash-10', 80], ['hard-slash-11', 80], 
                ['hard-slash-12', 60], ['hard-slash-13', 60], ['hard-slash-14', 60], 
                ['hard-slash-14', -2], 
            ],
        };

        this.initialVelocity = {
            x: {
                [FighterState.WALK_FORWARD]: 180,
                [FighterState.WALK_BACKWARD]: -160,
            },
            jump: -420,
        };

        this.gravity = 1000;
    }
}