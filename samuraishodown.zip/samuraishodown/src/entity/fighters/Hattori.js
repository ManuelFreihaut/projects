import { FighterState, PushBox, HurtBox } from '../../constants/fighter.js';
import { Fighter } from './Fighter.js';

export class Hattori extends Fighter {

    constructor(playerId) {
        super('Hattori', playerId);

        this.image = document.querySelector('img[alt="hattori"]');
    
        let i = 91;
        let f = 104;
        let b = 94;

        let c = 82;

        this.frames = new Map([
            // Idle Stance
            ['idle-0', [[[0, 0, i, 150], [38, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-1', [[[i, 0, i, 150], [38, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-2', [[[i * 2, 0, i, 150], [38, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-3', [[[i * 3, 0, i, 150], [38, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-4', [[[i * 4, 0, i, 150], [38, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-5', [[[i * 5, 0, i, 150], [38, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-6', [[[i * 6, 0, i, 150], [38, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-7', [[[i * 7, 0, i, 150], [38, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-8', [[[i * 8, 0, i, 150], [38, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-9', [[[i * 9, 0, i, 150], [38, 150]], PushBox.IDLE, HurtBox.IDLE]],

            // Move Forwards
            ['forwards-0', [[[0, 0, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-1', [[[f, 0, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-2', [[[f * 2, 0, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-3', [[[f * 3, 0, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-4', [[[f * 4, 0, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-5', [[[f * 5, 0, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-6', [[[f * 6, 0, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-7', [[[f * 7, 0, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-8', [[[f * 8, 0, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-9', [[[f * 9, 0, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],

            // Move Backwards
            ['backwards-0', [[[0, 0, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-1', [[[b, 0, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-2', [[[b * 2, 0, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-3', [[[b * 3, 0, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-4', [[[b * 4, 0, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-5', [[[b * 5, 0, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-6', [[[b * 6, 0, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-7', [[[b * 7, 0, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-8', [[[b * 8, 0, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-9', [[[b * 9, 0, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],

            // Jump Up
            ['jump-up-0', [[[0, 28, 74, 122], [30, 100]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-1', [[[76, 39, 62, 111], [30, 100]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-2', [[[150, 64, 62, 86], [30, 100]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-3', [[[224, 50, 63, 100], [30, 115]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-4', [[[298, 11, 62, 139], [30, 147]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-5', [[[370, 13, 74, 137], [31, 120]], PushBox.JUMP, HurtBox.JUMP]],

            // Crouch
            ['crouch-0', [[[0, 0, c, 150], [38, 150]], PushBox.IDLE, HurtBox.CROUCH]],
            ['crouch-1', [[[c, 0, c, 150], [38, 150]], PushBox.BEND, HurtBox.CROUCH]],
            ['crouch-2', [[[c * 2, 0, c, 150], [38, 150]], PushBox.CROUCH, HurtBox.CROUCH]],

            // Stand Turn
            ['idle-turn-0', [[[0, 47, 81, 103], [36, 103]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-turn-1', [[[116, 46, 82, 103], [40, 103]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-turn-2', [[[229, 45, 84, 105], [44, 105]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-turn-3', [[[344, 46, 86, 104], [43, 104]], PushBox.IDLE, HurtBox.IDLE]],

            // Crouch Turn
            ['crouch-turn-0', [[[465, 64, 69, 86], [36, 85]], PushBox.CROUCH, HurtBox.CROUCH]],
            ['crouch-turn-1', [[[584, 65, 66, 85], [36, 85]], PushBox.CROUCH, HurtBox.CROUCH]],
            ['crouch-turn-2', [[[697, 65, 69, 84], [36, 85]], PushBox.CROUCH, HurtBox.CROUCH]],
            ['crouch-turn-3', [[[812, 64, 69, 86], [36, 85]], PushBox.CROUCH, HurtBox.CROUCH]],

            // Light Slashes
            ['light-slash-0', [[[32, 57, 85, 111], [40, 111]], PushBox.IDLE, HurtBox.SLASH]],
            ['light-slash-1', [[[133, 80, 145, 88], [40, 88]], PushBox.IDLE, HurtBox.SLASH]],
            ['light-slash-2', [[[293, 80, 145, 88], [40, 88]], PushBox.IDLE, HurtBox.SLASH]],
            ['light-slash-3', [[[450, 94, 106, 74], [40, 74]], PushBox.IDLE, HurtBox.SLASH]],
            ['light-slash-4', [[[567, 94, 151, 74], [40, 74]], PushBox.IDLE, HurtBox.SLASH, [61, -66, 50, 18]]],
            ['light-slash-5', [[[730, 94, 151, 74], [40, 74]], PushBox.IDLE, HurtBox.SLASH, [61, -66, 50, 18]]],
            ['light-slash-6', [[[887, 94, 106, 74], [40, 74]], PushBox.IDLE, HurtBox.SLASH]],
            ['light-slash-7', [[[1019, 62, 87, 106], [40, 106]], PushBox.IDLE, HurtBox.SLASH]],

            // Hard Slashes
            ['hard-slash-0', [[[54, 1780, 74, 84], [35, 84]], PushBox.IDLE, HurtBox.CROUCH]],
            ['hard-slash-1', [[[154, 1750, 57, 114], [0, 120]], PushBox.IDLE, [[20, -104, 24, 16], [-11, -74, 40, 42], [-11, -31, 40, 32]]]],
            ['hard-slash-2', [[[230, 1752, 95, 110], [-5, 134]], PushBox.IDLE, [[], [], []]]],
            ['hard-slash-3', [[[350, 1770, 118, 83], [-10, 115]], PushBox.IDLE, [[], [], []]]],
            ['hard-slash-4', [[[820, 1667, 110, 95], [-10, 120]], PushBox.IDLE, [[], [], []]]],
            ['hard-slash-5', [[[936, 1662, 118, 83], [-15, 134]], PushBox.IDLE, [[], [], []]]],
            ['hard-slash-6', [[[957, 1769, 110, 95], [-35, 135]], PushBox.IDLE, [[], [], []]]],
            ['hard-slash-7', [[[490, 1728, 113, 136], [-20, 150]], PushBox.IDLE, [[], [], []], [87, -120, 50, 18]]],
            ['hard-slash-8', [[[632, 1735, 119, 129], [-25, 129]], PushBox.IDLE, [[], [], []], [101, -66, 50, 18]]],
            ['hard-slash-9', [[[766, 1782, 120, 83], [-25, 83]], PushBox.IDLE, [[], [], []], [90, -26, 50, 18]]],
            ['hard-slash-10', [[[44, 1938, 119, 83], [-20, 83]], PushBox.IDLE, [[80, -60, 24, 16], [61, -44, 40, 42], [-0, -0, 0, 0]], [91, -20, 50, 18]]],
            ['hard-slash-11', [[[190, 1950, 68, 71], [-15, 71]], PushBox.IDLE, [[40, -64, 24, 16], [-11, -74, 40, 42], [-11, -31, 40, 32]]]],
            ['hard-slash-12', [[[295, 1927, 73, 94], [15, 94]], PushBox.IDLE, [[5, -88, 24, 16], [-11, -74, 40, 42], [-11, -31, 40, 32]]]],
        ]);

        this.animations = {
            [FighterState.IDLE]: [
                ['idle-0', 80], ['idle-1', 80], ['idle-2', 80], 
                ['idle-3', 80], ['idle-4', 80], ['idle-5', 80], 
                ['idle-6', 80], ['idle-7', 80], ['idle-8', 80],
                ['idle-9', 80],
            ],
            [FighterState.WALK_FORWARD]: [
                ['forwards-0', 60], ['forwards-1', 60], ['forwards-2', 60], 
                ['forwards-3', 60], ['forwards-4', 60], ['forwards-5', 60], 
                ['forwards-6', 60], ['forwards-7', 60], ['forwards-8', 60],
                ['forwards-9', 60],
            ],
            [FighterState.WALK_BACKWARD]: [
                ['backwards-0', 60], ['backwards-1', 60], ['backwards-2', 60], 
                ['backwards-3', 60], ['backwards-4', 60], ['backwards-5', 60], 
                ['backwards-6', 60], ['backwards-7', 60], ['backwards-8', 60],
                ['backwards-9', 60],
            ],
            [FighterState.JUMP_UP]: [
                ['jump-up-0', 120], ['jump-up-1', 120], ['jump-up-2', 140],
                ['jump-up-3', 140], ['jump-up-4', 120], ['jump-up-5', 120],
            ],
            [FighterState.CROUCH]: [
                ['crouch-2', 0]
            ],
            [FighterState.CROUCH_DOWN]: [
                ['crouch-0', 50], ['crouch-1', 50], ['crouch-2', 50], ['crouch-1', -2],
            ],
            [FighterState.CROUCH_UP]: [
                ['crouch-2', 50], ['crouch-1', 50], ['crouch-0', 50], ['crouch-1', -2],
            ],
            [FighterState.IDLE_TURN]: [
                ['idle-turn-3', 65], ['idle-turn-2', 65], ['idle-turn-1', 65], ['idle-turn-0', 65], ['idle-turn-0', -2],
            ],
            [FighterState.CROUCH_TURN]: [
                ['crouch-turn-3', 65], ['crouch-turn-2', 65], ['crouch-turn-1', 65], ['crouch-turn-0', 65], ['crouch-turn-0', -2],
            ],
            [FighterState.LIGHT_SLASH]: [
                ['light-slash-0', 50], ['light-slash-1', 30], ['light-slash-2', 30], 
                ['light-slash-3', 30], ['light-slash-4', 30], ['light-slash-5', 30], 
                ['light-slash-6', 90], ['light-slash-7', 80], ['light-slash-7', -2],
            ],
            [FighterState.HARD_SLASH]: [
                ['hard-slash-0', 200], ['hard-slash-1', 80], ['hard-slash-2', 40], 
                ['hard-slash-3', 40], ['hard-slash-4', 40], ['hard-slash-5', 40], 
                ['hard-slash-6', 40], ['hard-slash-7', 30], ['hard-slash-8', 30], 
                ['hard-slash-9', 80], ['hard-slash-10', 100], ['hard-slash-11', 40], 
                ['hard-slash-12', 60], ['hard-slash-12', -2], 
            ],
        };

        this.initialVelocity = {
            x: {
                [FighterState.WALK_FORWARD]: 180,
                [FighterState.WALK_BACKWARD]: -160,
                [FighterState.HARD_SLASH]: 10,
            },
            jump: -420,
        };

        this.gravity = 1000;
    }
}