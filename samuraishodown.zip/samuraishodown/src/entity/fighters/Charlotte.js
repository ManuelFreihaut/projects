import { FighterState, PushBox, HurtBox } from '../../constants/fighter.js';
import { Fighter } from './Fighter.js';

export class Charlotte extends Fighter {

    constructor(playerId) {
        super('Charlotte', playerId);

        this.image = document.querySelector('img[alt="charlotte"]');

        let i = 107;
        let f = 114;
        let b = 115;
        let ju = 98;
        let c = 94;
    
        this.frames = new Map([
            // Idle Stance
            ['idle-0', [[[0, 0, i, 150], [35, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-1', [[[i, 0, i, 150], [35, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-2', [[[i * 2, 0, i, 150], [35, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-3', [[[i * 3, 0, i, 150], [35, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-4', [[[i * 4, 0, i, 150], [35, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-5', [[[i * 5, 0, i, 150], [35, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-6', [[[0, 150, i, 150], [35, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-7', [[[i, 150, i, 150], [35, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-8', [[[i * 2, 150, i, 150], [35, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-9', [[[i * 3, 150, i, 150], [35, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-10', [[[i * 4, 150, i, 150], [35, 150]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-11', [[[i * 5, 150, i, 150], [35, 150]], PushBox.IDLE, HurtBox.IDLE]],
            
            // Move Forwards
            ['forwards-0', [[[0, 0, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-1', [[[f, 0, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-2', [[[f * 2, 0, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-3', [[[f * 3, 0, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-4', [[[f * 4, 0, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-5', [[[0, 150, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-6', [[[f, 150, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-7', [[[f * 2, 150, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-8', [[[f * 3, 150, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],
            ['forwards-9', [[[f * 4, 150, f, 150], [f / 2, 150]], PushBox.IDLE, HurtBox.FORWARD]],

            // Move Backwards
            ['backwards-0', [[[0, 0, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-1', [[[b, 0, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-2', [[[b * 2, 0, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-3', [[[b * 3, 0, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-4', [[[b * 4, 0, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-5', [[[0, 150, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-6', [[[b, 150, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-7', [[[b * 2, 150, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-8', [[[b * 3, 150, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],
            ['backwards-9', [[[b * 4, 150, b, 150], [b / 2, 150]], PushBox.IDLE, HurtBox.BACKWARD]],

            // Jump Up
            ['jump-up-0', [[[0, 0, ju, 137], [ju / 2 - 20, 137]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-1', [[[ju, 0, ju, 137], [ju / 2 - 20, 137]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-2', [[[ju * 2, 0, ju, 137], [ju / 2 - 20, 137]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-3', [[[ju * 3, 0, ju, 137], [ju / 2 - 20, 137]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-4', [[[ju * 4, 0, ju, 137], [ju / 2 - 20, 137]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-5', [[[ju * 5, 0, ju, 137], [ju / 2 - 20, 137]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-6', [[[ju * 6, 0, ju, 137], [ju / 2 - 20, 137]], PushBox.JUMP, HurtBox.JUMP]],
            ['jump-up-7', [[[ju * 7, 0, ju, 137], [ju / 2 - 20, 137]], PushBox.JUMP, HurtBox.JUMP]],
        
            // Crouch
            ['crouch-0', [[[0, 0, c, 150], [30, 150]], PushBox.IDLE, HurtBox.CROUCH]],
            ['crouch-1', [[[c, 0, c, 150], [30, 150]], PushBox.BEND, HurtBox.CROUCH]],
            ['crouch-2', [[[c * 2, 0, c, 150], [30, 150]], PushBox.CROUCH, HurtBox.CROUCH]],

            // Stand Turn
            ['idle-turn-0', [[[0, 34, 84, 116], [32, 116]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-turn-1', [[[126, 14, 71, 135], [35, 136]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-turn-2', [[[259, 12, 66, 136], [30, 136]], PushBox.IDLE, HurtBox.IDLE]],
            ['idle-turn-3', [[[369, 30, 87, 120], [52, 120]], PushBox.IDLE, HurtBox.IDLE]],

            // Crouch Turn
            ['crouch-turn-0', [[[520, 57, 84, 93], [32, 92]], PushBox.CROUCH, HurtBox.CROUCH]],
            ['crouch-turn-1', [[[647, 46, 64, 104], [37, 102]], PushBox.CROUCH, HurtBox.CROUCH]],
            ['crouch-turn-2', [[[785, 33, 62, 117], [28, 115]], PushBox.CROUCH, HurtBox.CROUCH]],
            ['crouch-turn-3', [[[895, 52, 83, 98], [52, 98]], PushBox.CROUCH, HurtBox.CROUCH]],

            // Light Slashes
            ['light-slash-0', [[[42, 58, 73, 117], [45, 117]], PushBox.IDLE, HurtBox.SLASH]],
            ['light-slash-1', [[[144, 62, 138, 113], [45, 113]], PushBox.IDLE, HurtBox.SLASH]],
            ['light-slash-2', [[[306, 62, 146, 113], [45, 113]], PushBox.IDLE, HurtBox.SLASH]],
            ['light-slash-3', [[[480, 77, 177, 98], [45, 98]], PushBox.IDLE, HurtBox.SLASH, [31, -73, 50, 18]]],
            ['light-slash-4', [[[685, 77, 186 ,98], [45, 98]], PushBox.IDLE, HurtBox.SLASH, [88, -73, 50, 18]]],
            ['light-slash-5', [[[909, 77, 185, 98], [45, 98]], PushBox.IDLE, HurtBox.SLASH, [75, -73, 50, 18]]],
            ['light-slash-6', [[[41, 231, 184, 98], [45, 98]], PushBox.IDLE, HurtBox.SLASH, [68, -73, 50, 18]]],
            ['light-slash-7', [[[252, 216, 138, 111], [45, 111]], PushBox.IDLE, HurtBox.SLASH]],

            // Hard Slashes
            ['hard-slash-0', [[[31, 2751, 72, 118], [35, 118]], PushBox.IDLE, HurtBox.SLASH]],
            ['hard-slash-1', [[[132, 2752, 63, 117], [35, 117]], PushBox.IDLE, HurtBox.SLASH]],
            ['hard-slash-2', [[[217, 2755, 172, 114], [45, 114]], PushBox.IDLE, HurtBox.SLASH]],
            ['hard-slash-3', [[[407, 2754, 173, 115], [45, 115]], PushBox.IDLE, HurtBox.SLASH]],
            ['hard-slash-4', [[[608, 2760, 129, 109], [45, 109]], PushBox.IDLE, HurtBox.SLASH]],
            ['hard-slash-5', [[[763, 2752, 180, 117], [45, 117]], PushBox.IDLE, HurtBox.SLASH, [71, -103, 50, 18]]],
            ['hard-slash-6', [[[968, 2752, 180, 117], [45, 117]], PushBox.IDLE, HurtBox.SLASH, [71, -93, 50, 18]]],
            ['hard-slash-7', [[[12, 2928, 100, 125], [70, 125]], PushBox.IDLE, HurtBox.SLASH, [65, -83, 50, 18]]],
            ['hard-slash-8', [[[127, 2928, 197, 125], [70, 125]], PushBox.IDLE, HurtBox.SLASH, [61, -73, 50, 18]]],
            ['hard-slash-9', [[[342, 2927, 99, 125], [70, 125]], PushBox.IDLE, HurtBox.SLASH, [50, -43, 50, 18]]],
            ['hard-slash-10', [[[451, 2924, 192, 129], [80, 129]], PushBox.IDLE, HurtBox.SLASH]],
            ['hard-slash-11', [[[656, 2927, 99, 126], [71, 126]], PushBox.IDLE, HurtBox.SLASH]],
            ['hard-slash-12', [[[761, 2924, 108, 128], [80, 128]], PushBox.IDLE, HurtBox.SLASH]],
            ['hard-slash-13', [[[883, 2924, 108, 129], [75, 129]], PushBox.IDLE, HurtBox.SLASH]],
            ['hard-slash-14', [[[1029, 2935, 72, 118], [35, 118]], PushBox.IDLE, HurtBox.SLASH]],
        ]);

        this.animations = {
            [FighterState.IDLE]: [
                ['idle-0', 80], ['idle-1', 80], ['idle-2', 80], 
                ['idle-3', 80], ['idle-4', 80], ['idle-5', 80], 
                ['idle-6', 80], ['idle-7', 80], ['idle-8', 80],
                ['idle-9', 80], ['idle-10', 80], ['idle-11', 80]
            ],
            [FighterState.WALK_FORWARD]: [
                ['forwards-0', 60], ['forwards-1', 60], ['forwards-2', 60], 
                ['forwards-3', 60], ['forwards-4', 60], ['forwards-5', 60], 
                ['forwards-6', 60], ['forwards-7', 60], ['forwards-8', 60],
                ['forwards-9', 60]
            ],
            [FighterState.WALK_BACKWARD]: [
                ['backwards-0', 80], ['backwards-1', 80], ['backwards-2', 80], 
                ['backwards-3', 80], ['backwards-4', 80], ['backwards-5', 80], 
                ['backwards-6', 80], ['backwards-7', 80], ['backwards-8', 80], 
                ['backwards-9', 80]
            ],
            [FighterState.JUMP_UP]: [
                ['jump-up-0', 80], ['jump-up-1', 100], ['jump-up-2', 100],
                ['jump-up-3', 150], ['jump-up-4', 150], ['jump-up-5', 100],
                ['jump-up-6', 100], ['jump-up-7', 80]
            ],//, 'jump-up-1', 'jump-up-2', 'jump-up-3', 'jump-up-4', 'jump-up-5', 'jump-up-6', 'jump-up-7'],
            [FighterState.CROUCH]: [
                ['crouch-2', 0]
            ],
            [FighterState.CROUCH_DOWN]: [
                ['crouch-0', 50], ['crouch-1', 50], ['crouch-2', 50], ['crouch-1', -2],
            ],
            [FighterState.CROUCH_UP]: [
                ['crouch-2', 50], ['crouch-1', 50], ['crouch-0', 50], ['crouch-1', -2],
            ],
            [FighterState.IDLE_TURN]: [
                ['idle-turn-3', 65], ['idle-turn-2', 65], ['idle-turn-1', 65], ['idle-turn-0', 65], ['idle-turn-0', -2],
            ],
            [FighterState.CROUCH_TURN]: [
                ['crouch-turn-3', 65], ['crouch-turn-2', 65], ['crouch-turn-1', 65], ['crouch-turn-0', 65], ['crouch-turn-0', -2],
            ],
            [FighterState.LIGHT_SLASH]: [
                ['light-slash-0', 100], ['light-slash-1', 20], ['light-slash-2', 20], 
                ['light-slash-3', 20], ['light-slash-4', 20], ['light-slash-5', 20], 
                ['light-slash-6', 20], ['light-slash-7', 20], ['light-slash-7', -2],
            ],
            [FighterState.HARD_SLASH]: [
                ['hard-slash-0', 120], ['hard-slash-1', 120], ['hard-slash-2', 50], 
                ['hard-slash-3', 20], ['hard-slash-4', 20], ['hard-slash-5', 20], 
                ['hard-slash-6', 70], ['hard-slash-7', 50], ['hard-slash-8', 20], 
                ['hard-slash-9', 50], ['hard-slash-10', 50], ['hard-slash-11', 50], 
                ['hard-slash-12', 50], ['hard-slash-13', 50], ['hard-slash-14', 50], 
                ['hard-slash-14', -2]
            ],
        };

        this.initialVelocity = {
            x: {
                [FighterState.WALK_FORWARD]: 180,
                [FighterState.WALK_BACKWARD]: -160,
            },
            jump: -420,
        };

        this.gravity = 1000;
    }
}
