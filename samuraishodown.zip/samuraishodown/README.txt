Samurai Shodown V

This project was made by Freihaut Manuel

The code is from Shezzor. I typed things down and adapted them to get as close as possible to the original game.
This is a part of my summer-project from the second grade in the HTBLALEONDING. 
I tried to understand the code as much as possible. It really helped me understanding the world of programming more.
Try the code with the Live Server Extension in Google Chrome. 
Just in case, you want to change Characters or Stage, navigate to gameState.js, stage.js, fighter.js and BattleScene.js.
There are helping comments! :-J
Have Fun!