package at.htlleonding.lfst;

public class SimpleOrder extends OrderComponent{

    private String description;
    private double price;

    public SimpleOrder(String description, double price) {
        super();
        this.description = description;
        this.price = price;
    }

    @Override
    public String getDescription() {
        return String.format("Bestell ID: %d, Möbelstück: %s", this.getId(), this.description);
    }

    @Override
    public double getPrice() {
        return this.price;
    }
}
