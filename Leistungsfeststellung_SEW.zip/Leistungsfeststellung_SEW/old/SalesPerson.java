package at.htlleonding.lfst;

import java.util.Random;

public class SalesPerson extends Thread{
    private String name;
    private BlockingOrderQueue queue;
    private OrderFactory factory;
    private boolean isActive;

    public SalesPerson(BlockingOrderQueue queue, OrderFactory factory, String name, boolean isActive) {
        this.queue = queue;
        this.factory = factory;
        this.name = name;
        this.isActive = isActive;
    }

    public void stopWorker() {
        this.isActive = false;
    }
    public void activateWorker() {
        this.isActive = true;
    }

/*
    @Override
    public void run() {
        Random rd = new Random();
        OrderComponent order;

        try {
            while(isActive) {
                do {
                    order = factory.createOrder();
                    this.queue.put(order);
                    System.out.println(name + " bearbeitet Bestellung: " + order.getDescription());
                    Thread.sleep(rd.nextInt(2000, 5000));

                } while (factory.createOrder() != null);
            }

        } catch (InterruptedException ex) {
            System.err.println(name + " wurde unterbrochen.");
        }
    }*/
@Override
public void run() {
    Random rd = new Random();
    try{
        OrderComponent order;
        while((order = factory.createOrder())!=null){
            System.out.println(name+" bearbeitet Bestellung: " + order.getDescription());
            queue.put(order);
            Thread.sleep(rd.nextLong(1000,5000));
        }
    } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        System.err.println(name+" wurde unterbrochen.");
    }
}
}
