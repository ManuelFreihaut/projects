package at.htlleonding.lfst;

public class Main {
    public static void main(String[] args) {
        try {
            String[] orders = {"SIMPLE;Sessel;49.99","SIMPLE;Tisch;199.99","COMPOSITE;Tisch-Set;5","SIMPLE;Sessel;49.99","SIMPLE;Sessel;49.99","SIMPLE;Sessel;49.99","SIMPLE;Sessel;49.99","SIMPLE;Tisch;199.99"};
            BlockingOrderQueue queue = new BlockingOrderQueue(10);
            OrderFactory factory = new OrderFactory(orders);

            SalesPerson s1 = new SalesPerson(queue,factory,"Richard", true);
            SalesPerson s2 = new SalesPerson(queue,factory,"Julian", true);

            WarehouseWorker w1 = new WarehouseWorker(queue,"Chris", true);
            WarehouseWorker w2 = new WarehouseWorker(queue,"Deniz", true);

            s1.start();
            s2.start();
            w1.start();
            w2.start();

            Thread.sleep(10000);
            s1.interrupt();
            s2.interrupt();
            w1.interrupt();
            w2.interrupt();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
