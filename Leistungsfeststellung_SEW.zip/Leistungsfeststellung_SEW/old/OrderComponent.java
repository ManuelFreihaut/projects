package at.htlleonding.lfst;

public abstract class OrderComponent {
    private static int run = 0;
    private int id;

    public OrderComponent() {
        this.id = run += 1;
    }
    public int getId(){
        return this.id;
    }

    public abstract String getDescription();

    public abstract double getPrice();

}
