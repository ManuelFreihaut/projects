package at.htlleonding.lfst;

import java.util.LinkedList;
import java.util.Queue;

public class BlockingOrderQueue{

    private Queue<OrderComponent> orders;
    private int limit;

    public BlockingOrderQueue(int limit) {
        this.limit = limit;
        this.orders = new LinkedList<>();
    }
    public synchronized void put(OrderComponent order) throws InterruptedException {
        while(orders.size() == this.limit) {
            wait();
        }
        orders.add(order);
        if(orders.size() == 1) {
            notifyAll();
        }
    }
    public synchronized OrderComponent take() throws InterruptedException {
        while(orders.isEmpty()) {
            wait();
        }
        OrderComponent result = orders.poll();

        if(orders.size() + 1 == limit) {
            notifyAll();
        }
        return result;
    }


}
