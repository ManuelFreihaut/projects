package at.htlleonding.lfst;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class OrderFactory {
    private String[] lines;
    private Iterator<String[]> iterator;

    public OrderFactory(String[] lines) {
        this.lines = lines;
        List<String[]> list = new LinkedList<>();

        for(String line : lines){
            list.add(line.split(";"));

        }
        iterator = list.iterator();
    }
    protected SimpleOrder createSimpleOrder(String[] data){
        double price = Double.parseDouble(data[2]);
        return new SimpleOrder(data[1],price);
    }
    public OrderComponent createOrder(){
        if(!iterator.hasNext()){
            return null;
        }
        String[] data = iterator.next();
        if(data[0].trim().equals("SIMPLE")){
            return createSimpleOrder(data);
        }
        if (data[0].trim().equals("COMPOSITE")) {
            return createCompositeOrder(data);
        }
        return null;
    }
    protected CompositeOrder createCompositeOrder(String[] data){
        int iteration = Integer.parseInt(data[2]);
        CompositeOrder co =  new CompositeOrder(data[1]);
        for (int i = 0; i < iteration; i++) {
            co.addComponent(createOrder());
        }
        return co;
    }
}
