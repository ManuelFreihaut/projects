package at.htlleonding.lfst;

import java.util.LinkedList;

public class CompositeOrder extends OrderComponent {

    private String description;
    private LinkedList<OrderComponent> components;

    public CompositeOrder(String description) {
        super();
        this.description = description;
        this.components = new LinkedList<>();
    }

    public void addComponent(OrderComponent component) {
        this.components.add(component);
    }

    @Override
    public String getDescription() {
        String description = String.format("Kombinierte Bestell-ID: %d, Beschreibung: %s\n", this.getId(), this.description);

        for(OrderComponent o : this.components) {
            description += String.format("\n %s", o.getDescription());;
        }
        return description;
    }

    @Override
    public double getPrice() {
        double price = 0;

        for(OrderComponent o : this.components) {
            price += o.getPrice();
        }
        return price;
    }
}
