package at.htlleonding.lfst;

import java.util.Random;

public class WarehouseWorker extends Thread{
    private String name;
    private BlockingOrderQueue queue;
    private boolean isActive;

    public WarehouseWorker(BlockingOrderQueue queue, String name, boolean isActive) {
        this.queue = queue;
        this.name = name;
        this.isActive = isActive;
    }

    public void stopWorker() {
        this.isActive = false;
    }
    public void activateWorker() {
        this.isActive = true;
    }

    /*@Override
    public void run() {
        Random rd = new Random();
        try {
            OrderComponent order;
            while(isActive) {
                do {
                    order = queue.take();
                    System.out.println(name + " holt Bestellung ab: " + order.getDescription());
                    Thread.sleep(rd.nextInt(2000, 5000));
                } while(order != null);
            }
        } catch (InterruptedException ex) {
            System.err.println(name + " wurde unterbrochen.");
        }
    }*/
    @Override
    public void run() {
        Random rd = new Random();
        try{
            while(!Thread.currentThread().isInterrupted()){
                OrderComponent order = queue.take();
                System.out.println(name + " holt Bestellung ab: " + order.getDescription());
                Thread.sleep(rd.nextLong(1000,5000));
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println(name+" wurde unterbrochen.");
        }
        try{
            OrderComponent o = queue.take();
            while(o != null){
                System.out.println(name + " holt Bestellung ab: " + o.getDescription());
                Thread.sleep(rd.nextLong(1000,5000));
                o = queue.take();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println(name+" wurde unterbrochen.");
        }
    }
}
