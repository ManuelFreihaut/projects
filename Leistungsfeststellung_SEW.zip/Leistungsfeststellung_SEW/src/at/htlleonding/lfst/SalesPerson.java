package at.htlleonding.lfst;

import java.util.Random;

public class SalesPerson implements Runnable{

    private BlockingOrderQueue queue;
    private OrderFactory factory;
    private String name;

    public SalesPerson(BlockingOrderQueue queue, OrderFactory factory, String name) {
        this.queue = queue;
        this.factory = factory;
        this.name = name;
    }

    public String getTName() {
        return this.name;
    }

    @Override
    public void run() {
        Random rd = new Random();
        OrderComponent order;
        try {
            while((order = factory.createOrder())!=null){
                System.out.println(name + " bearbeitet Bestellung: " + order.getDescription());
                this.queue.put(order);
                Thread.sleep(rd.nextLong(1000, 5000));
            }

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
