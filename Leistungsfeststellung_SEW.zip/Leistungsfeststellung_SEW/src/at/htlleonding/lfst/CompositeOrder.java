package at.htlleonding.lfst;

import java.util.LinkedList;
import java.util.List;

public class CompositeOrder extends OrderComponent{

    private String description;
    private List<OrderComponent> components;

    public CompositeOrder(String description) {
        super();
        this.description = description;
        this.components = new LinkedList<>();
    }

    public void addComponent(OrderComponent component) {
        this.components.add(component);
    }

    @Override
    public double getPrice() {
        double result = 0;
        for(OrderComponent component : this.components) {
            result += component.getPrice();
        }
        return result;
    }

    @Override
    public String getDescription() {
        String result = String.format("Kombinierte Bestell-ID: %d, Beschreibung: %s\n", this.getId(), this.description);
        for(OrderComponent component : this.components) {
            result += String.format("\n %s", component.getDescription());
        }
        return  result;
    }
}
