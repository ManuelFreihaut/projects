package at.htlleonding.lfst;

import java.util.LinkedList;
import java.util.Queue;

public class BlockingOrderQueue {

    private int limit;
    private Queue<OrderComponent> queue;

    public BlockingOrderQueue(int limit) {
        this.limit = limit;
        this.queue = new LinkedList<>();
    }

    public synchronized void put(OrderComponent order) throws InterruptedException {
        if(this.queue.size() == this.limit) {
            wait();
        }
        this.queue.add(order);
        if(this.queue.size() == 1) {
            notifyAll();
        }
    }

    public synchronized OrderComponent take() throws InterruptedException {
        if(queue.isEmpty()) {
            wait();
        }
        OrderComponent result = this.queue.poll();
        if(this.queue.size() + 1 == this.limit) {
            notifyAll();
        }

        return result;
    }


}
