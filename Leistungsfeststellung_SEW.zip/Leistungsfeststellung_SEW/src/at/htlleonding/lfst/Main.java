package at.htlleonding.lfst;

import java.io.IOException;

public class Main {
    public static void main(String[] args) {

        OrderFactory factory;
        BlockingOrderQueue queue = new BlockingOrderQueue(10);

        {
            try {
                factory = new OrderFactory("./data/furniture.txt");

                Thread s1 = new Thread(new SalesPerson(queue, factory, "Ufo361"));
                Thread s2 = new Thread(new SalesPerson(queue, factory, "Capital Bra"));

                Thread w1 = new Thread(new WarehouseWorker(queue, "Sonja"));
                Thread w2 = new Thread(new WarehouseWorker(queue, "Melanie"));

                s1.start();
                s2.start();

                w1.start();
                w2.start();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
