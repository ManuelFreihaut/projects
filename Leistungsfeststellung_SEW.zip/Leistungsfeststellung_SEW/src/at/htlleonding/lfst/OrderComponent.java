package at.htlleonding.lfst;

public abstract class OrderComponent {

    private static int run = 0;
    private int id;

    public OrderComponent() {
        this.id = run += 1; //this.id = ++run;

    }
    public int getId() {
        return this.id;
    }

    public abstract double getPrice();

    public abstract String getDescription();

    @Override
    public String toString() {
        return getDescription();
    }
}
