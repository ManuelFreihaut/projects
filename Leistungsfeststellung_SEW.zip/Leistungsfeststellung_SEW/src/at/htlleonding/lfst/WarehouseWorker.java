package at.htlleonding.lfst;

import java.util.Random;

public class WarehouseWorker implements Runnable {

    private BlockingOrderQueue queue;
    private String name;

    public WarehouseWorker(BlockingOrderQueue queue, String name) {
        this.queue = queue;
        this.name = name;
    }

    public String getTName() {
        return this.name;
    }

    @Override
    public void run() {
        Random rd = new Random();
        try {

            OrderComponent o = queue.take();
            while(o != null){
                System.out.println(name + " holt Bestellung ab: " + o.getDescription());
                Thread.sleep(rd.nextLong(1000,5000));
                o = queue.take();
            }
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
